select *
from V1_multasActuales
where matricula in ('5665-AJT','2210-GTT') and fecha 
between '2024-01-01' and '2024-04-30';
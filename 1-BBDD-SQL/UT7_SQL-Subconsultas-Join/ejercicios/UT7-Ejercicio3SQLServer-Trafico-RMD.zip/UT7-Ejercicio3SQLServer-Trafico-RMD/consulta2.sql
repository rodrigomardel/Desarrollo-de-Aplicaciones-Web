select direccion, fecha_nacimiento
from V2_propietariosSinVehiculo
where nombre like 'esteban' and Apellido like 'cuesta'
select curso, cod_curso, Nombre_Profesor, Nombre_Alumno
from V3_datosGenerales
where curso like 'matem�ticas' and Nota_final>6
select nombre, apellidos, direccion, nota_final
from V1_alumnosYcursos
where curso like 'ofim�tica'
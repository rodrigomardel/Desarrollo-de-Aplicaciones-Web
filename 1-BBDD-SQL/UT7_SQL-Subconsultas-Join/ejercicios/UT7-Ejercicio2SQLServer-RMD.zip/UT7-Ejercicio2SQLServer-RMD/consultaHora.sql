select nombre, apellidos, direccion, poblacion
from v2_profesoresYcursos
where h_inicio like '18:00%'